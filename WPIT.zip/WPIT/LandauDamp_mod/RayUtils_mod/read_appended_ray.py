import pandas as pd    


def read_appended_ray(ray_file_name):
    df=pd.read_csv(ray_file_name)

    

    return df