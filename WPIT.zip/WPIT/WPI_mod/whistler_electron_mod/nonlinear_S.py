import numpy as np


def nonlinear_S(H,wtsq):
    tmp=H/wtsq
    return tmp