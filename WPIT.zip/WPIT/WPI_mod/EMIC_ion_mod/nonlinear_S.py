import numpy as np

def nonlinear_S(H_arg,wtsq_arg):
    tmp=H_arg/wtsq_arg
    return tmp